var jsonData = [
    {
        "q" : "How long does it take for glass to decompose",
        "opt1" : "1 million years",
        "opt2" : "1 billion years",
        "opt3" : "100 years",
        "answer" : "1 million years"
    },
    {
        "q" : "Which country currently emits the most greenhouse gases",
        "opt1" : "Russia",
        "opt2" : "China",
        "opt3" : "USA",
        "answer" : "China"
    },
    {
        "q" : "For every tone of paper recycled,How many trees are saved",
        "opt1" : "59",
        "opt2" : "32",
        "opt3" : "17",
        "answer" : "17"
    },
    {
        "q" : "What is the theme of World Environment Day 2021?",
        "opt1" : "Ecosystem Restoration",
        "opt2" : "Restore Our Earth",
        "opt3" : "Connecting People with Nature",
        "answer" : "Ecosystem Restoration"
    },
    {
        "q" : "The first World Environment Day was held in which year?",
        "opt1" : "1974",
        "opt2" : "1976",
        "opt3" : "1971",
        "answer" :"1974"
    }
];